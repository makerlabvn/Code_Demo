RS485-TTL :
TXD--------5
RXD--------4
VCC--------5V (Min 4.75V)
GND-------GND

URM14_RS485 sensor:
Brown: 7->15V (Vin Uno)
Black: GND (UNO)
Blue: B (RS485-TTL)
White: A (RS485-TTL)